# Assignment 2: Word Sense Disambiguation using HMM and Overlapping  
For knowing the tools and how to run the code check individual folder's readme files  
**Folder Structure**  
.  
├── slides.pdf  
├── readme.md  
├── WEOverlap  
│   ├── overlapping_wsd.py  
│   └── readme.md  
└── HMM  
    ├── main.py  
    ├── hmm_wsd_incl_untagged.py  
    ├── hmm_wsd_excluding_untagged.py  
    └── readme.md
    
____________________________________________________________________________________________________  
UPDATE:  
----------------------------------------------------------------------------------------------------  
The slides have been updated and a new second last slide is added to describe the improvement of HMM 
____________________________________________________________________________________________________  
