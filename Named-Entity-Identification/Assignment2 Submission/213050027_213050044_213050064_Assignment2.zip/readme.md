# Assignment 2: Word Sense Disambiguation using HMM and Overlapping  
For knowing the tools and how to run the code check individual folder's readme files  
**Folder Structure**  
|
HMM  
  |___ hmm_wsd_excluding_untagged.py  
  |___ hmm_wsd_incl_untagged.py  
  |___ main.py  
  |___ readme.md  
WEOverlap  
  |___ overlapping_wsd.py  
  |___ readme.md  
readme.md  
slides.pdf  
